#include <map>
#include <XBotInterface/ModelInterface.h>
#include <XBotInterface/RobotInterface.h>
#include <memory>


#include <XBotInterface/RobotInterface.h>
#include <XBotInterface/Utils.h>
#include <RobotInterfaceROS/ConfigFromParam.h>
#include "ros/ros.h"
#include "vector"

class CommonUtils
{
    
public:
    
    static XBot::ConfigOptions RetrieveRobotConfig(const std::string& robot_name);

    static bool RetrieveModel(const std::string &robot_name,
                              const std::string &model_name,
                              bool allow_new_model,
                              uint8_t &model_id,
                              XBot::ModelInterface::Ptr &model,
                              std::string &error_info);
    
    static bool RetrieveRobot(const std::string &robot_name,
                              bool allow_new_robot,
                              uint8_t &robot_id,
                              XBot::RobotInterface::Ptr &robot,
                              std::string &error_info);
    
    static bool setExternalModel(const std::string &model_name,
                                 XBot::ModelInterface::Ptr model,
                                 std::string &error_info);
    
    static bool setExternalRobot(const std::string &robot_name,
                                 XBot::RobotInterface::Ptr robot,
                                 std::string &error_info);
    
    static bool RetrieveModelId(uint8_t &model_id);
    
    static bool RetrieveRobotId(uint8_t &robot_id);
    
    static bool isValidModelID(uint8_t model_id);
    
    static bool isValidRobotID(uint8_t robot_id);
    
    static void clearModelMap();
    
    static void clearRobotMap();
    
    static bool checkXBotCorePresence();
    
    static void setXBotCorePresence(bool value);
    
    static bool getXBotCorePresence();
    
    static void checkParamSelected(std::string param_selection,std::vector<std::string> &param_selected);
    
    static uint8_t get_max_number_robots();
    
private:
    static std::map<std::string,std::map<uint8_t, XBot::ModelInterface::Ptr>> _mdl_map;
    static std::map<std::string,std::map<uint8_t, XBot::RobotInterface::Ptr>> _rbt_map;
    static bool _xbotcore_presence;
    static bool _floating_base_param;
    static const uint8_t _max_number_robots;
};
